import { PrismaClient, EmploymentType, Role } from "@prisma/client";

const prisma = new PrismaClient();

/**
 * Replace these ids with real Supabase auth user ids (auth.users.id)
 * if you want to log in as the demo accounts.
 */
const EMPLOYER_ID = "00000000-0000-4000-8000-000000000001";
const SEEKER_ID = "00000000-0000-4000-8000-000000000002";

async function main() {
  const employer = await prisma.profile.upsert({
    where: { id: EMPLOYER_ID },
    update: {},
    create: {
      id: EMPLOYER_ID,
      email: "demo-employer@jobconnect.co.il",
      fullName: "נטע רוזן",
      role: Role.EMPLOYER,
      city: "תל אביב",
      phone: "0521234567",
    },
  });

  const seeker = await prisma.profile.upsert({
    where: { id: SEEKER_ID },
    update: {},
    create: {
      id: SEEKER_ID,
      email: "demo-seeker@jobconnect.co.il",
      fullName: "עומר לוי",
      role: Role.SEEKER,
      city: "חיפה",
      phone: "0537654321",
    },
  });

  await prisma.job.deleteMany({ where: { authorId: employer.id } });
  await prisma.workerPost.deleteMany({ where: { authorId: seeker.id } });

  await prisma.job.createMany({
    data: [
      {
        title: "מלצר/ית למשמרות ערב",
        description:
          "מסעדה שכונתית בפלורנטין מחפשת מלצר/ית למשמרות ערב, 4–5 משמרות בשבוע. טיפים גבוהים, ארוחות עובדים, צוות קבוע.",
        company: "מסעדת בזל",
        city: "תל אביב",
        salary: "55 ₪ לשעה + טיפים",
        employmentType: EmploymentType.SHIFTS,
        phone: "0521234567",
        whatsapp: "972521234567",
        email: "jobs@bazel.co.il",
        authorId: employer.id,
      },
      {
        title: "מפתח/ת Full-Stack",
        description:
          "חברת פינטק מגייסת מפתח/ת Full-Stack עם ניסיון ב-React ו-Node. מודל היברידי, שני ימים במשרד.",
        company: "Payflow",
        city: "רמת גן",
        salary: "28,000–36,000 ₪",
        employmentType: EmploymentType.FULL_TIME,
        phone: "0539876543",
        whatsapp: "972539876543",
        email: "careers@payflow.io",
        authorId: employer.id,
      },
      {
        title: "עובד/ת מחסן ולוגיסטיקה",
        description:
          "מחסן לוגיסטי מחפש עובד/ת לליקוט, אריזה וסידור סחורה. לא נדרש ניסיון, הכשרה במקום.",
        company: "לוגיפאסט",
        city: "אשדוד",
        salary: "42 ₪ לשעה",
        employmentType: EmploymentType.FULL_TIME,
        phone: "0501112233",
        whatsapp: "972501112233",
        email: "hr@logifast.co.il",
        authorId: employer.id,
      },
      {
        title: "מעצב/ת גרפי/ת",
        description:
          "סטודיו מיתוג מחפש מעצב/ת לפרויקטים של מיתוג ורשתות חברתיות. עבודה מרחוק, לפי פרויקט.",
        company: "סטודיו קו",
        city: "ירושלים",
        salary: "לפי פרויקט",
        employmentType: EmploymentType.CONTRACT,
        phone: "0544445555",
        whatsapp: "972544445555",
        email: "hello@kav.studio",
        authorId: employer.id,
      },
    ],
  });

  await prisma.workerPost.createMany({
    data: [
      {
        name: "עומר לוי",
        city: "חיפה",
        about:
          "טכנאי מיזוג מוסמך, מחפש עבודה קבועה באזור הצפון. רישיון נהיגה ורכב פרטי, זמין מיידית.",
        skills: ["מיזוג אוויר", "חשמל", "שירות לקוחות"],
        experience: "6 שנים",
        phone: "0537654321",
        whatsapp: "972537654321",
        email: "omer@example.com",
        authorId: seeker.id,
      },
      {
        name: "עומר לוי",
        city: "קריית ביאליק",
        about: "זמין גם למשמרות ערב ולעבודות התקנה נקודתיות בסופי שבוע.",
        skills: ["התקנות", "תיקונים"],
        experience: "6 שנים",
        phone: "0537654321",
        whatsapp: "972537654321",
        email: "omer@example.com",
        authorId: seeker.id,
      },
    ],
  });

  console.log("Seed complete.");
}

main()
  .catch((e) => {
    console.error(e);
    process.exit(1);
  })
  .finally(async () => {
    await prisma.$disconnect();
  });
