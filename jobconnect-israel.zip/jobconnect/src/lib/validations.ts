import { z } from "zod";

const phone = z
  .string()
  .trim()
  .regex(/^0\d{1,2}-?\d{7}$/, "מספר טלפון ישראלי לא תקין")
  .or(z.literal(""))
  .optional();

export const registerSchema = z.object({
  fullName: z.string().trim().min(2, "שם מלא חייב להכיל לפחות 2 תווים"),
  email: z.string().trim().email("כתובת אימייל לא תקינה"),
  password: z.string().min(8, "הסיסמה חייבת להכיל לפחות 8 תווים"),
  role: z.enum(["EMPLOYER", "SEEKER"], { message: "בחר/י סוג חשבון" }),
});
export type RegisterInput = z.infer<typeof registerSchema>;

export const loginSchema = z.object({
  email: z.string().trim().email("כתובת אימייל לא תקינה"),
  password: z.string().min(1, "הזן/י סיסמה"),
});
export type LoginInput = z.infer<typeof loginSchema>;

export const jobSchema = z.object({
  title: z.string().trim().min(3, "כותרת קצרה מדי").max(120),
  company: z.string().trim().min(2, "שם חברה קצר מדי").max(80),
  city: z.string().trim().min(2, "בחר/י עיר"),
  description: z.string().trim().min(20, "תיאור המשרה חייב להכיל לפחות 20 תווים").max(4000),
  salary: z.string().trim().max(80).optional().or(z.literal("")),
  employmentType: z.enum([
    "FULL_TIME",
    "PART_TIME",
    "CONTRACT",
    "TEMPORARY",
    "INTERNSHIP",
    "SHIFTS",
  ]),
  phone,
  whatsapp: phone,
  email: z.string().trim().email("כתובת אימייל לא תקינה").or(z.literal("")).optional(),
});
export type JobInput = z.infer<typeof jobSchema>;

export const workerSchema = z.object({
  name: z.string().trim().min(2, "שם קצר מדי").max(80),
  city: z.string().trim().min(2, "בחר/י עיר"),
  about: z.string().trim().min(20, "ספר/י על עצמך לפחות ב-20 תווים").max(2000),
  skills: z.array(z.string().trim().min(1)).min(1, "הוסף/י לפחות כישור אחד").max(12),
  experience: z.string().trim().max(80).optional().or(z.literal("")),
  phone,
  whatsapp: phone,
  email: z.string().trim().email("כתובת אימייל לא תקינה").or(z.literal("")).optional(),
});
export type WorkerInput = z.infer<typeof workerSchema>;

export const profileSchema = z.object({
  fullName: z.string().trim().min(2, "שם מלא חייב להכיל לפחות 2 תווים").max(80),
  city: z.string().trim().max(40).optional().or(z.literal("")),
  phone,
  avatarUrl: z.string().url().optional().or(z.literal("")),
});
export type ProfileInput = z.infer<typeof profileSchema>;

export const feedQuerySchema = z.object({
  q: z.string().trim().max(80).optional(),
  city: z.string().trim().max(40).optional(),
  employmentType: z
    .enum(["FULL_TIME", "PART_TIME", "CONTRACT", "TEMPORARY", "INTERNSHIP", "SHIFTS"])
    .optional(),
  page: z.coerce.number().int().min(1).default(1),
});
