import { NextResponse } from "next/server";
import { ZodError } from "zod";

export function jsonError(message: string, status = 400) {
  return NextResponse.json({ error: message }, { status });
}

export function handleError(error: unknown) {
  if (error instanceof ZodError) {
    return NextResponse.json(
      { error: "נתונים לא תקינים", issues: error.flatten().fieldErrors },
      { status: 422 },
    );
  }
  console.error(error);
  return jsonError("אירעה שגיאה בשרת. נסו שוב.", 500);
}

/** Minimal in-memory rate limiter — enough for a single-instance MVP. */
const hits = new Map<string, { count: number; resetAt: number }>();

export function rateLimit(key: string, limit = 20, windowMs = 60_000) {
  const now = Date.now();
  const entry = hits.get(key);

  if (!entry || entry.resetAt < now) {
    hits.set(key, { count: 1, resetAt: now + windowMs });
    return true;
  }

  entry.count += 1;
  return entry.count <= limit;
}
