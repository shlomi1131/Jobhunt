import type { EmploymentType, Role } from "@prisma/client";

export const CITIES = [
  "תל אביב",
  "ירושלים",
  "חיפה",
  "ראשון לציון",
  "פתח תקווה",
  "אשדוד",
  "נתניה",
  "באר שבע",
  "בני ברק",
  "חולון",
  "רמת גן",
  "אשקלון",
  "רחובות",
  "בת ים",
  "הרצליה",
  "כפר סבא",
  "מודיעין",
  "רעננה",
  "עפולה",
  "אילת",
  "עבודה מהבית",
] as const;

export const EMPLOYMENT_TYPES: { value: EmploymentType; label: string }[] = [
  { value: "FULL_TIME", label: "משרה מלאה" },
  { value: "PART_TIME", label: "משרה חלקית" },
  { value: "SHIFTS", label: "משמרות" },
  { value: "CONTRACT", label: "פרילנס / קבלן" },
  { value: "TEMPORARY", label: "זמני" },
  { value: "INTERNSHIP", label: "התמחות" },
];

export const employmentLabel = (type: EmploymentType) =>
  EMPLOYMENT_TYPES.find((t) => t.value === type)?.label ?? "משרה";

export const ROLES: { value: Role; label: string; description: string }[] = [
  {
    value: "EMPLOYER",
    label: "מעסיק",
    description: "מפרסם משרות ומחפש עובדים",
  },
  {
    value: "SEEKER",
    label: "מחפש/ת עבודה",
    description: "מפרסם פרופיל ומחפש משרות",
  },
];

export const PAGE_SIZE = 12;
