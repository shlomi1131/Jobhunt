import { redirect } from "next/navigation";
import type { Profile, Role } from "@prisma/client";
import { createClient } from "@/lib/supabase/server";
import { prisma } from "@/lib/prisma";

/**
 * Returns the signed-in user's profile, creating it on first access from the
 * Supabase auth metadata captured at registration.
 */
export async function getProfile(): Promise<Profile | null> {
  const supabase = await createClient();
  const {
    data: { user },
  } = await supabase.auth.getUser();

  if (!user) return null;

  const fullName =
    (user.user_metadata?.full_name as string | undefined)?.trim() ||
    user.email!.split("@")[0];
  const role = (user.user_metadata?.role as Role | undefined) ?? "SEEKER";

  return prisma.profile.upsert({
    where: { id: user.id },
    update: {},
    create: {
      id: user.id,
      email: user.email!,
      fullName,
      role,
    },
  });
}

export async function requireProfile(redirectTo = "/dashboard"): Promise<Profile> {
  const profile = await getProfile();
  if (!profile) {
    redirect(`/login?redirect=${encodeURIComponent(redirectTo)}`);
  }
  return profile;
}
