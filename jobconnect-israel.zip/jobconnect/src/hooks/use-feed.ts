"use client";

import { useInfiniteQuery } from "@tanstack/react-query";
import type { JobWithAuthor, Paginated, WorkerWithAuthor } from "@/types";

export type Filters = {
  q?: string;
  city?: string;
  employmentType?: string;
};

function toSearchParams(filters: Filters, page: number) {
  const params = new URLSearchParams({ page: String(page) });
  Object.entries(filters).forEach(([key, value]) => {
    if (value) params.set(key, value);
  });
  return params.toString();
}

async function fetchFeed<T>(
  resource: "jobs" | "workers",
  filters: Filters,
  page: number,
): Promise<Paginated<T>> {
  const response = await fetch(
    `/api/${resource}?${toSearchParams(filters, page)}`,
  );
  if (!response.ok) throw new Error("טעינת התוצאות נכשלה");
  return response.json();
}

export function useJobsFeed(filters: Filters) {
  return useInfiniteQuery({
    queryKey: ["jobs", filters],
    queryFn: ({ pageParam }) =>
      fetchFeed<JobWithAuthor>("jobs", filters, pageParam),
    initialPageParam: 1,
    getNextPageParam: (last) => (last.hasMore ? last.page + 1 : undefined),
  });
}

export function useWorkersFeed(filters: Filters) {
  return useInfiniteQuery({
    queryKey: ["workers", filters],
    queryFn: ({ pageParam }) =>
      fetchFeed<WorkerWithAuthor>("workers", filters, pageParam),
    initialPageParam: 1,
    getNextPageParam: (last) => (last.hasMore ? last.page + 1 : undefined),
  });
}
