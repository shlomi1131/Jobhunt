import type { Job, Profile, WorkerPost } from "@prisma/client";

export type Author = Pick<Profile, "id" | "fullName" | "avatarUrl">;

export type JobWithAuthor = Job & { author: Author };
export type WorkerWithAuthor = WorkerPost & { author: Author };

export type Paginated<T> = {
  items: T[];
  page: number;
  hasMore: boolean;
  total: number;
};
