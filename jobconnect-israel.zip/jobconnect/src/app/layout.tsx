import type { Metadata } from "next";
import { Rubik, Assistant, IBM_Plex_Mono } from "next/font/google";
import { Providers } from "./providers";
import { SiteHeader } from "@/components/site-header";
import { SiteFooter } from "@/components/site-footer";
import "./globals.css";

const display = Rubik({
  subsets: ["hebrew", "latin"],
  weight: ["500", "600", "700", "800"],
  variable: "--font-display",
  display: "swap",
});

const body = Assistant({
  subsets: ["hebrew", "latin"],
  weight: ["400", "500", "600"],
  variable: "--font-body",
  display: "swap",
});

const mono = IBM_Plex_Mono({
  subsets: ["latin"],
  weight: ["400", "500"],
  variable: "--font-mono",
  display: "swap",
});

const siteUrl = process.env.NEXT_PUBLIC_SITE_URL ?? "http://localhost:3000";

export const metadata: Metadata = {
  metadataBase: new URL(siteUrl),
  title: {
    default: "JobConnect — לוח משרות ועובדים בישראל",
    template: "%s | JobConnect",
  },
  description:
    "לוח שמחבר בין מעסיקים לעובדים בישראל. פרסמו משרה, פרסמו פרופיל עובד, וצרו קשר בלחיצה אחת.",
  openGraph: {
    type: "website",
    locale: "he_IL",
    url: siteUrl,
    title: "JobConnect — לוח משרות ועובדים בישראל",
    description: "פרסמו משרה או פרופיל עובד, וצרו קשר ישירות. בלי מתווכים.",
  },
  robots: { index: true, follow: true },
};

export default function RootLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return (
    <html
      lang="he"
      dir="rtl"
      suppressHydrationWarning
      className={`${display.variable} ${body.variable} ${mono.variable}`}
    >
      <body className="min-h-dvh">
        <Providers>
          <div className="flex min-h-dvh flex-col">
            <SiteHeader />
            <main className="flex-1">{children}</main>
            <SiteFooter />
          </div>
        </Providers>
      </body>
    </html>
  );
}
