import { NextResponse, type NextRequest } from "next/server";
import { prisma } from "@/lib/prisma";
import { getProfile } from "@/lib/auth";
import { profileSchema } from "@/lib/validations";
import { handleError, jsonError } from "@/lib/api";

export async function GET() {
  const profile = await getProfile();
  if (!profile) return jsonError("נדרשת התחברות", 401);
  return NextResponse.json(profile);
}

export async function PATCH(request: NextRequest) {
  try {
    const profile = await getProfile();
    if (!profile) return jsonError("נדרשת התחברות", 401);

    const data = profileSchema.parse(await request.json());

    const updated = await prisma.profile.update({
      where: { id: profile.id },
      data: {
        fullName: data.fullName,
        city: data.city || null,
        phone: data.phone || null,
        avatarUrl: data.avatarUrl || null,
      },
    });

    return NextResponse.json(updated);
  } catch (error) {
    return handleError(error);
  }
}
