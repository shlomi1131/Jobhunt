import { NextResponse, type NextRequest } from "next/server";
import { prisma } from "@/lib/prisma";
import { getProfile } from "@/lib/auth";
import { feedQuerySchema, jobSchema } from "@/lib/validations";
import { handleError, jsonError, rateLimit } from "@/lib/api";
import { PAGE_SIZE } from "@/lib/constants";
import type { Prisma } from "@prisma/client";

export async function GET(request: NextRequest) {
  try {
    const params = Object.fromEntries(request.nextUrl.searchParams);
    const { q, city, employmentType, page } = feedQuerySchema.parse(params);

    const where: Prisma.JobWhereInput = {
      ...(city ? { city } : {}),
      ...(employmentType ? { employmentType } : {}),
      ...(q
        ? {
            OR: [
              { title: { contains: q, mode: "insensitive" } },
              { description: { contains: q, mode: "insensitive" } },
              { company: { contains: q, mode: "insensitive" } },
            ],
          }
        : {}),
    };

    const [items, total] = await Promise.all([
      prisma.job.findMany({
        where,
        orderBy: { createdAt: "desc" },
        skip: (page - 1) * PAGE_SIZE,
        take: PAGE_SIZE,
        include: {
          author: { select: { id: true, fullName: true, avatarUrl: true } },
        },
      }),
      prisma.job.count({ where }),
    ]);

    return NextResponse.json({
      items,
      page,
      total,
      hasMore: page * PAGE_SIZE < total,
    });
  } catch (error) {
    return handleError(error);
  }
}

export async function POST(request: NextRequest) {
  try {
    const profile = await getProfile();
    if (!profile) return jsonError("נדרשת התחברות", 401);
    if (profile.role !== "EMPLOYER") {
      return jsonError("רק חשבון מעסיק יכול לפרסם משרות", 403);
    }
    if (!rateLimit(`job:${profile.id}`, 10)) {
      return jsonError("יותר מדי בקשות. נסו שוב בעוד דקה.", 429);
    }

    const data = jobSchema.parse(await request.json());

    const job = await prisma.job.create({
      data: { ...data, authorId: profile.id },
    });

    return NextResponse.json(job, { status: 201 });
  } catch (error) {
    return handleError(error);
  }
}
