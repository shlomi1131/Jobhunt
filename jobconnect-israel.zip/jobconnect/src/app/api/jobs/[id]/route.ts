import { NextResponse, type NextRequest } from "next/server";
import { prisma } from "@/lib/prisma";
import { getProfile } from "@/lib/auth";
import { jobSchema } from "@/lib/validations";
import { handleError, jsonError } from "@/lib/api";

type Params = { params: Promise<{ id: string }> };

export async function GET(_request: NextRequest, { params }: Params) {
  try {
    const { id } = await params;
    const job = await prisma.job.findUnique({
      where: { id },
      include: {
        author: { select: { id: true, fullName: true, avatarUrl: true } },
      },
    });

    if (!job) return jsonError("המשרה לא נמצאה", 404);
    return NextResponse.json(job);
  } catch (error) {
    return handleError(error);
  }
}

export async function PATCH(request: NextRequest, { params }: Params) {
  try {
    const { id } = await params;
    const profile = await getProfile();
    if (!profile) return jsonError("נדרשת התחברות", 401);

    const existing = await prisma.job.findUnique({ where: { id } });
    if (!existing) return jsonError("המשרה לא נמצאה", 404);
    if (existing.authorId !== profile.id) {
      return jsonError("אין הרשאה לערוך משרה זו", 403);
    }

    const data = jobSchema.parse(await request.json());
    const job = await prisma.job.update({ where: { id }, data });

    return NextResponse.json(job);
  } catch (error) {
    return handleError(error);
  }
}

export async function DELETE(_request: NextRequest, { params }: Params) {
  try {
    const { id } = await params;
    const profile = await getProfile();
    if (!profile) return jsonError("נדרשת התחברות", 401);

    const existing = await prisma.job.findUnique({ where: { id } });
    if (!existing) return jsonError("המשרה לא נמצאה", 404);
    if (existing.authorId !== profile.id) {
      return jsonError("אין הרשאה למחוק משרה זו", 403);
    }

    await prisma.job.delete({ where: { id } });
    return NextResponse.json({ ok: true });
  } catch (error) {
    return handleError(error);
  }
}
