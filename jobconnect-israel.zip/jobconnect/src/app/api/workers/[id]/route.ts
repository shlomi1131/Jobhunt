import { NextResponse, type NextRequest } from "next/server";
import { prisma } from "@/lib/prisma";
import { getProfile } from "@/lib/auth";
import { workerSchema } from "@/lib/validations";
import { handleError, jsonError } from "@/lib/api";

type Params = { params: Promise<{ id: string }> };

export async function GET(_request: NextRequest, { params }: Params) {
  try {
    const { id } = await params;
    const post = await prisma.workerPost.findUnique({
      where: { id },
      include: {
        author: { select: { id: true, fullName: true, avatarUrl: true } },
      },
    });

    if (!post) return jsonError("הפרופיל לא נמצא", 404);
    return NextResponse.json(post);
  } catch (error) {
    return handleError(error);
  }
}

export async function PATCH(request: NextRequest, { params }: Params) {
  try {
    const { id } = await params;
    const profile = await getProfile();
    if (!profile) return jsonError("נדרשת התחברות", 401);

    const existing = await prisma.workerPost.findUnique({ where: { id } });
    if (!existing) return jsonError("הפרופיל לא נמצא", 404);
    if (existing.authorId !== profile.id) {
      return jsonError("אין הרשאה לערוך פרסום זה", 403);
    }

    const data = workerSchema.parse(await request.json());
    const post = await prisma.workerPost.update({ where: { id }, data });

    return NextResponse.json(post);
  } catch (error) {
    return handleError(error);
  }
}

export async function DELETE(_request: NextRequest, { params }: Params) {
  try {
    const { id } = await params;
    const profile = await getProfile();
    if (!profile) return jsonError("נדרשת התחברות", 401);

    const existing = await prisma.workerPost.findUnique({ where: { id } });
    if (!existing) return jsonError("הפרופיל לא נמצא", 404);
    if (existing.authorId !== profile.id) {
      return jsonError("אין הרשאה למחוק פרסום זה", 403);
    }

    await prisma.workerPost.delete({ where: { id } });
    return NextResponse.json({ ok: true });
  } catch (error) {
    return handleError(error);
  }
}
