import { NextResponse, type NextRequest } from "next/server";
import { prisma } from "@/lib/prisma";
import { getProfile } from "@/lib/auth";
import { feedQuerySchema, workerSchema } from "@/lib/validations";
import { handleError, jsonError, rateLimit } from "@/lib/api";
import { PAGE_SIZE } from "@/lib/constants";
import type { Prisma } from "@prisma/client";

export async function GET(request: NextRequest) {
  try {
    const params = Object.fromEntries(request.nextUrl.searchParams);
    const { q, city, page } = feedQuerySchema.parse(params);

    const where: Prisma.WorkerPostWhereInput = {
      ...(city ? { city } : {}),
      ...(q
        ? {
            OR: [
              { name: { contains: q, mode: "insensitive" } },
              { about: { contains: q, mode: "insensitive" } },
              { skills: { has: q } },
            ],
          }
        : {}),
    };

    const [items, total] = await Promise.all([
      prisma.workerPost.findMany({
        where,
        orderBy: { createdAt: "desc" },
        skip: (page - 1) * PAGE_SIZE,
        take: PAGE_SIZE,
        include: {
          author: { select: { id: true, fullName: true, avatarUrl: true } },
        },
      }),
      prisma.workerPost.count({ where }),
    ]);

    return NextResponse.json({
      items,
      page,
      total,
      hasMore: page * PAGE_SIZE < total,
    });
  } catch (error) {
    return handleError(error);
  }
}

export async function POST(request: NextRequest) {
  try {
    const profile = await getProfile();
    if (!profile) return jsonError("נדרשת התחברות", 401);
    if (profile.role !== "SEEKER") {
      return jsonError("רק חשבון מחפש עבודה יכול לפרסם פרופיל", 403);
    }
    if (!rateLimit(`worker:${profile.id}`, 10)) {
      return jsonError("יותר מדי בקשות. נסו שוב בעוד דקה.", 429);
    }

    const data = workerSchema.parse(await request.json());

    const post = await prisma.workerPost.create({
      data: { ...data, authorId: profile.id },
    });

    return NextResponse.json(post, { status: 201 });
  } catch (error) {
    return handleError(error);
  }
}
