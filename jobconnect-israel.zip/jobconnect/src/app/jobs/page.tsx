import { Suspense } from "react";
import type { Metadata } from "next";
import { JobsFeed } from "@/components/jobs-feed";
import { CardSkeletonGrid } from "@/components/card-skeleton";

export const metadata: Metadata = {
  title: "משרות",
  description: "כל המשרות הפתוחות — סינון לפי עיר והיקף משרה.",
};

export default function JobsPage() {
  return (
    <div className="container py-12">
      <header className="mb-8">
        <p className="meta-rail">לוח משרות</p>
        <h1 className="mt-2 font-display text-3xl font-extrabold tracking-tight sm:text-4xl">
          משרות פתוחות
        </h1>
        <p className="mt-2 text-muted-foreground">
          חפשו לפי תפקיד, סננו לפי עיר והיקף, וצרו קשר ישירות עם המעסיק.
        </p>
      </header>

      <Suspense fallback={<CardSkeletonGrid />}>
        <JobsFeed />
      </Suspense>
    </div>
  );
}
