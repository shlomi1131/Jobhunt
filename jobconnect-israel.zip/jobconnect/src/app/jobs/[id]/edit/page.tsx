import type { Metadata } from "next";
import { notFound, redirect } from "next/navigation";
import { prisma } from "@/lib/prisma";
import { requireProfile } from "@/lib/auth";
import { JobForm } from "@/components/job-form";

export const metadata: Metadata = { title: "עריכת משרה" };

type Props = { params: Promise<{ id: string }> };

export default async function EditJobPage({ params }: Props) {
  const { id } = await params;
  const profile = await requireProfile(`/jobs/${id}/edit`);
  const job = await prisma.job.findUnique({ where: { id } });

  if (!job) notFound();
  if (job.authorId !== profile.id) redirect(`/jobs/${id}`);

  return (
    <div className="container max-w-3xl py-12">
      <header className="mb-8">
        <p className="meta-rail">עריכה</p>
        <h1 className="mt-2 font-display text-3xl font-extrabold tracking-tight">
          {job.title}
        </h1>
      </header>

      <JobForm job={job} />
    </div>
  );
}
