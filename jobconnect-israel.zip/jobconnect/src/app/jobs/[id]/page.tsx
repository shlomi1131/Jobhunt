import type { Metadata } from "next";
import Link from "next/link";
import { notFound } from "next/navigation";
import { Building2, MapPin, Pencil } from "lucide-react";
import { prisma } from "@/lib/prisma";
import { getProfile } from "@/lib/auth";
import { employmentLabel } from "@/lib/constants";
import { timeAgo } from "@/lib/utils";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { ContactButtons } from "@/components/contact-buttons";
import { DeleteButton } from "@/components/delete-button";

type Props = { params: Promise<{ id: string }> };

export async function generateMetadata({ params }: Props): Promise<Metadata> {
  const { id } = await params;
  const job = await prisma.job.findUnique({ where: { id } });
  if (!job) return { title: "המשרה לא נמצאה" };

  return {
    title: `${job.title} — ${job.company}`,
    description: job.description.slice(0, 160),
  };
}

export default async function JobPage({ params }: Props) {
  const { id } = await params;

  const [job, profile] = await Promise.all([
    prisma.job.findUnique({
      where: { id },
      include: {
        author: { select: { id: true, fullName: true, avatarUrl: true } },
      },
    }),
    getProfile(),
  ]);

  if (!job) notFound();

  const isOwner = profile?.id === job.authorId;

  return (
    <div className="container max-w-3xl py-12">
      <article className="rounded-2xl border border-border bg-card shadow-card">
        <div className="meta-rail border-b border-dashed border-border px-6 py-3">
          <span>{employmentLabel(job.employmentType)}</span>
          <span className="rail-dot" />
          <span>{job.salary || "שכר לא צוין"}</span>
          <span className="ms-auto normal-case tracking-normal">
            {timeAgo(job.createdAt)}
          </span>
        </div>

        <div className="p-6 sm:p-8">
          <h1 className="font-display text-3xl font-extrabold leading-tight tracking-tight">
            {job.title}
          </h1>

          <div className="mt-3 flex flex-wrap items-center gap-x-5 gap-y-2 text-sm text-muted-foreground">
            <span className="inline-flex items-center gap-1.5">
              <Building2 className="h-4 w-4" /> {job.company}
            </span>
            <span className="inline-flex items-center gap-1.5">
              <MapPin className="h-4 w-4" /> {job.city}
            </span>
          </div>

          <div className="mt-5 flex flex-wrap gap-2">
            <Badge variant="solid">{employmentLabel(job.employmentType)}</Badge>
            <Badge variant="outline">{job.city}</Badge>
            {job.salary ? <Badge variant="accent">{job.salary}</Badge> : null}
          </div>

          <div className="mt-8 whitespace-pre-line text-[15px] leading-relaxed">
            {job.description}
          </div>

          <div className="mt-10 border-t border-border pt-6">
            <p className="meta-rail mb-3">יצירת קשר</p>
            <ContactButtons
              phone={job.phone}
              whatsapp={job.whatsapp}
              email={job.email}
              shareTitle={job.title}
              shareUrl={`/jobs/${job.id}`}
              size="default"
            />
            <p className="mt-4 text-xs text-muted-foreground">
              פורסם על ידי {job.author.fullName}
            </p>
          </div>

          {isOwner ? (
            <div className="mt-6 flex flex-wrap items-center gap-2 rounded-xl bg-secondary/60 p-3">
              <span className="me-auto ps-2 text-sm text-muted-foreground">
                זו המשרה שלכם
              </span>
              <Button variant="outline" size="sm" asChild>
                <Link href={`/jobs/${job.id}/edit`}>
                  <Pencil /> עריכה
                </Link>
              </Button>
              <DeleteButton resource="jobs" id={job.id} title={job.title} />
            </div>
          ) : null}
        </div>
      </article>
    </div>
  );
}
