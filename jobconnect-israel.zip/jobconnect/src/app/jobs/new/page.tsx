import type { Metadata } from "next";
import Link from "next/link";
import { requireProfile } from "@/lib/auth";
import { Button } from "@/components/ui/button";
import { JobForm } from "@/components/job-form";

export const metadata: Metadata = { title: "פרסום משרה" };

export default async function NewJobPage() {
  const profile = await requireProfile("/jobs/new");

  if (profile.role !== "EMPLOYER") {
    return (
      <div className="container max-w-2xl py-16 text-center">
        <h1 className="font-display text-2xl font-extrabold">
          פרסום משרה זמין לחשבון מעסיק
        </h1>
        <p className="mt-2 text-muted-foreground">
          החשבון שלכם מוגדר כמחפש/ת עבודה. אפשר לפרסם פרופיל עובד במקום.
        </p>
        <Button className="mt-6" asChild>
          <Link href="/workers/new">פרסום פרופיל עובד</Link>
        </Button>
      </div>
    );
  }

  return (
    <div className="container max-w-3xl py-12">
      <header className="mb-8">
        <p className="meta-rail">משרה חדשה</p>
        <h1 className="mt-2 font-display text-3xl font-extrabold tracking-tight">
          פרסום משרה
        </h1>
        <p className="mt-2 text-muted-foreground">
          ככל שהפרטים מדויקים יותר, כך יפנו אליכם מועמדים מתאימים יותר.
        </p>
      </header>

      <JobForm />
    </div>
  );
}
