import type { Metadata } from "next";
import Link from "next/link";
import { Pencil, Plus } from "lucide-react";
import { prisma } from "@/lib/prisma";
import { requireProfile } from "@/lib/auth";
import { employmentLabel } from "@/lib/constants";
import { timeAgo } from "@/lib/utils";
import { Button } from "@/components/ui/button";
import { EmptyState } from "@/components/empty-state";
import { DeleteButton } from "@/components/delete-button";

export const metadata: Metadata = { title: "הפרסומים שלי" };
export const dynamic = "force-dynamic";

export default async function DashboardPage() {
  const profile = await requireProfile("/dashboard");
  const isEmployer = profile.role === "EMPLOYER";

  const [jobs, posts] = await Promise.all([
    isEmployer
      ? prisma.job.findMany({
          where: { authorId: profile.id },
          orderBy: { createdAt: "desc" },
        })
      : Promise.resolve([]),
    !isEmployer
      ? prisma.workerPost.findMany({
          where: { authorId: profile.id },
          orderBy: { createdAt: "desc" },
        })
      : Promise.resolve([]),
  ]);

  const count = isEmployer ? jobs.length : posts.length;

  return (
    <div className="container max-w-4xl py-12">
      <header className="mb-8 flex flex-wrap items-end justify-between gap-4">
        <div>
          <p className="meta-rail">
            <span>{isEmployer ? "חשבון מעסיק" : "חשבון מחפש/ת עבודה"}</span>
            <span className="rail-dot" />
            <span>{count} פרסומים</span>
          </p>
          <h1 className="mt-2 font-display text-3xl font-extrabold tracking-tight">
            הפרסומים שלי
          </h1>
        </div>

        <Button variant="accent" asChild>
          <Link href={isEmployer ? "/jobs/new" : "/workers/new"}>
            <Plus /> {isEmployer ? "פרסום משרה" : "פרסום פרופיל"}
          </Link>
        </Button>
      </header>

      {count === 0 ? (
        <EmptyState
          title="עוד לא פרסמתם כלום"
          description={
            isEmployer
              ? "פרסמו משרה ראשונה — מועמדים יוכלו ליצור אתכם קשר ישירות."
              : "פרסמו פרופיל ראשון — מעסיקים יוכלו למצוא אתכם."
          }
          actionLabel={isEmployer ? "פרסום משרה" : "פרסום פרופיל"}
          actionHref={isEmployer ? "/jobs/new" : "/workers/new"}
        />
      ) : (
        <ul className="flex flex-col gap-4">
          {isEmployer
            ? jobs.map((job) => (
                <li
                  key={job.id}
                  className="rounded-2xl border border-border bg-card p-5 shadow-card"
                >
                  <div className="meta-rail">
                    <span>{employmentLabel(job.employmentType)}</span>
                    <span className="rail-dot" />
                    <span>{job.city}</span>
                    <span className="ms-auto normal-case tracking-normal">
                      {timeAgo(job.createdAt)}
                    </span>
                  </div>

                  <h2 className="mt-3 font-display text-lg font-bold">
                    <Link href={`/jobs/${job.id}`} className="hover:text-primary">
                      {job.title}
                    </Link>
                  </h2>
                  <p className="mt-1 text-sm text-muted-foreground">{job.company}</p>

                  <div className="mt-4 flex flex-wrap gap-2">
                    <Button variant="outline" size="sm" asChild>
                      <Link href={`/jobs/${job.id}/edit`}>
                        <Pencil /> עריכה
                      </Link>
                    </Button>
                    <DeleteButton resource="jobs" id={job.id} title={job.title} />
                  </div>
                </li>
              ))
            : posts.map((post) => (
                <li
                  key={post.id}
                  className="rounded-2xl border border-border bg-card p-5 shadow-card"
                >
                  <div className="meta-rail">
                    <span>פרופיל עובד</span>
                    <span className="rail-dot" />
                    <span>{post.city}</span>
                    <span className="ms-auto normal-case tracking-normal">
                      {timeAgo(post.createdAt)}
                    </span>
                  </div>

                  <h2 className="mt-3 font-display text-lg font-bold">
                    <Link href={`/workers/${post.id}`} className="hover:text-primary">
                      {post.name}
                    </Link>
                  </h2>
                  <p className="mt-1 line-clamp-1 text-sm text-muted-foreground">
                    {post.about}
                  </p>

                  <div className="mt-4 flex flex-wrap gap-2">
                    <Button variant="outline" size="sm" asChild>
                      <Link href={`/workers/${post.id}/edit`}>
                        <Pencil /> עריכה
                      </Link>
                    </Button>
                    <DeleteButton resource="workers" id={post.id} title={post.name} />
                  </div>
                </li>
              ))}
        </ul>
      )}
    </div>
  );
}
