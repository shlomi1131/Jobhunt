import { Suspense } from "react";
import type { Metadata } from "next";
import { WorkersFeed } from "@/components/workers-feed";
import { CardSkeletonGrid } from "@/components/card-skeleton";

export const metadata: Metadata = {
  title: "עובדים",
  description: "פרופילים של מחפשי עבודה — סינון לפי עיר.",
};

export default function WorkersPage() {
  return (
    <div className="container py-12">
      <header className="mb-8">
        <p className="meta-rail">לוח עובדים</p>
        <h1 className="mt-2 font-display text-3xl font-extrabold tracking-tight sm:text-4xl">
          עובדים שמחפשים עבודה
        </h1>
        <p className="mt-2 text-muted-foreground">
          חפשו לפי כישור או תחום, סננו לפי עיר, והתקשרו ישירות.
        </p>
      </header>

      <Suspense fallback={<CardSkeletonGrid />}>
        <WorkersFeed />
      </Suspense>
    </div>
  );
}
