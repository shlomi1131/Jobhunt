import type { Metadata } from "next";
import Link from "next/link";
import { notFound } from "next/navigation";
import { Briefcase, MapPin, Pencil } from "lucide-react";
import { prisma } from "@/lib/prisma";
import { getProfile } from "@/lib/auth";
import { initials, timeAgo } from "@/lib/utils";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { ContactButtons } from "@/components/contact-buttons";
import { DeleteButton } from "@/components/delete-button";

type Props = { params: Promise<{ id: string }> };

export async function generateMetadata({ params }: Props): Promise<Metadata> {
  const { id } = await params;
  const post = await prisma.workerPost.findUnique({ where: { id } });
  if (!post) return { title: "הפרופיל לא נמצא" };

  return {
    title: `${post.name} — ${post.city}`,
    description: post.about.slice(0, 160),
  };
}

export default async function WorkerPage({ params }: Props) {
  const { id } = await params;

  const [post, profile] = await Promise.all([
    prisma.workerPost.findUnique({
      where: { id },
      include: {
        author: { select: { id: true, fullName: true, avatarUrl: true } },
      },
    }),
    getProfile(),
  ]);

  if (!post) notFound();

  const isOwner = profile?.id === post.authorId;

  return (
    <div className="container max-w-3xl py-12">
      <article className="rounded-2xl border border-border bg-card shadow-card">
        <div className="meta-rail border-b border-dashed border-border px-6 py-3">
          <span>מחפש/ת עבודה</span>
          <span className="rail-dot" />
          <span>{post.experience || "ללא ניסיון"}</span>
          <span className="ms-auto normal-case tracking-normal">
            {timeAgo(post.createdAt)}
          </span>
        </div>

        <div className="p-6 sm:p-8">
          <div className="flex items-start gap-4">
            <Avatar className="h-14 w-14">
              {post.author.avatarUrl ? (
                <AvatarImage src={post.author.avatarUrl} alt={post.name} />
              ) : null}
              <AvatarFallback>{initials(post.name)}</AvatarFallback>
            </Avatar>
            <div>
              <h1 className="font-display text-3xl font-extrabold leading-tight tracking-tight">
                {post.name}
              </h1>
              <div className="mt-2 flex flex-wrap items-center gap-x-5 gap-y-2 text-sm text-muted-foreground">
                <span className="inline-flex items-center gap-1.5">
                  <MapPin className="h-4 w-4" /> {post.city}
                </span>
                {post.experience ? (
                  <span className="inline-flex items-center gap-1.5">
                    <Briefcase className="h-4 w-4" /> {post.experience} ניסיון
                  </span>
                ) : null}
              </div>
            </div>
          </div>

          {post.skills.length ? (
            <div className="mt-6 flex flex-wrap gap-2">
              {post.skills.map((skill: string) => (
                <Badge key={skill}>{skill}</Badge>
              ))}
            </div>
          ) : null}

          <div className="mt-8 whitespace-pre-line text-[15px] leading-relaxed">
            {post.about}
          </div>

          <div className="mt-10 border-t border-border pt-6">
            <p className="meta-rail mb-3">יצירת קשר</p>
            <ContactButtons
              phone={post.phone}
              whatsapp={post.whatsapp}
              email={post.email}
              shareTitle={post.name}
              shareUrl={`/workers/${post.id}`}
              size="default"
            />
          </div>

          {isOwner ? (
            <div className="mt-6 flex flex-wrap items-center gap-2 rounded-xl bg-secondary/60 p-3">
              <span className="me-auto ps-2 text-sm text-muted-foreground">
                זה הפרסום שלכם
              </span>
              <Button variant="outline" size="sm" asChild>
                <Link href={`/workers/${post.id}/edit`}>
                  <Pencil /> עריכה
                </Link>
              </Button>
              <DeleteButton resource="workers" id={post.id} title={post.name} />
            </div>
          ) : null}
        </div>
      </article>
    </div>
  );
}
