import type { Metadata } from "next";
import { notFound, redirect } from "next/navigation";
import { prisma } from "@/lib/prisma";
import { requireProfile } from "@/lib/auth";
import { WorkerForm } from "@/components/worker-form";

export const metadata: Metadata = { title: "עריכת פרופיל עובד" };

type Props = { params: Promise<{ id: string }> };

export default async function EditWorkerPage({ params }: Props) {
  const { id } = await params;
  const profile = await requireProfile(`/workers/${id}/edit`);
  const post = await prisma.workerPost.findUnique({ where: { id } });

  if (!post) notFound();
  if (post.authorId !== profile.id) redirect(`/workers/${id}`);

  return (
    <div className="container max-w-3xl py-12">
      <header className="mb-8">
        <p className="meta-rail">עריכה</p>
        <h1 className="mt-2 font-display text-3xl font-extrabold tracking-tight">
          {post.name}
        </h1>
      </header>

      <WorkerForm post={post} />
    </div>
  );
}
