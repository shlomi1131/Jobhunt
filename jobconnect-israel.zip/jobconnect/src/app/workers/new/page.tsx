import type { Metadata } from "next";
import Link from "next/link";
import { requireProfile } from "@/lib/auth";
import { Button } from "@/components/ui/button";
import { WorkerForm } from "@/components/worker-form";

export const metadata: Metadata = { title: "פרסום פרופיל עובד" };

export default async function NewWorkerPage() {
  const profile = await requireProfile("/workers/new");

  if (profile.role !== "SEEKER") {
    return (
      <div className="container max-w-2xl py-16 text-center">
        <h1 className="font-display text-2xl font-extrabold">
          פרסום פרופיל זמין לחשבון מחפש/ת עבודה
        </h1>
        <p className="mt-2 text-muted-foreground">
          החשבון שלכם מוגדר כמעסיק. אפשר לפרסם משרה במקום.
        </p>
        <Button className="mt-6" asChild>
          <Link href="/jobs/new">פרסום משרה</Link>
        </Button>
      </div>
    );
  }

  return (
    <div className="container max-w-3xl py-12">
      <header className="mb-8">
        <p className="meta-rail">פרופיל חדש</p>
        <h1 className="mt-2 font-display text-3xl font-extrabold tracking-tight">
          פרסום פרופיל עובד
        </h1>
        <p className="mt-2 text-muted-foreground">
          ספרו מה אתם עושים ומתי אתם זמינים — מעסיקים יפנו אליכם ישירות.
        </p>
      </header>

      <WorkerForm defaultName={profile.fullName} />
    </div>
  );
}
