import Link from "next/link";
import { ArrowLeft } from "lucide-react";
import { prisma } from "@/lib/prisma";
import { Button } from "@/components/ui/button";
import { JobCard } from "@/components/job-card";
import { WorkerCard } from "@/components/worker-card";
import { HomeSearch } from "@/components/home-search";
import { EmptyState } from "@/components/empty-state";

export const dynamic = "force-dynamic";

const authorSelect = {
  author: { select: { id: true, fullName: true, avatarUrl: true } },
} as const;

export default async function HomePage() {
  const [jobs, workers, jobCount, workerCount] = await Promise.all([
    prisma.job.findMany({
      orderBy: { createdAt: "desc" },
      take: 6,
      include: authorSelect,
    }),
    prisma.workerPost.findMany({
      orderBy: { createdAt: "desc" },
      take: 6,
      include: authorSelect,
    }),
    prisma.job.count(),
    prisma.workerPost.count(),
  ]);

  return (
    <div className="flex flex-col gap-20 pb-8">
      {/* Hero */}
      <section className="border-b border-border bg-card">
        <div className="container grid gap-10 py-16 lg:grid-cols-[1.1fr_1fr] lg:items-center lg:py-24">
          <div className="animate-fade-up">
            <p className="meta-rail">
              <span>לוח משרות ישראלי</span>
              <span className="rail-dot" />
              <span>{jobCount} משרות</span>
              <span className="rail-dot" />
              <span>{workerCount} עובדים</span>
            </p>

            <h1 className="mt-5 font-display text-4xl font-extrabold leading-[1.1] tracking-tight sm:text-5xl lg:text-6xl">
              העבודה הבאה שלכם{" "}
              <span className="text-primary">נמצאת במרחק שיחה אחת.</span>
            </h1>

            <p className="mt-5 max-w-lg text-lg leading-relaxed text-muted-foreground">
              מעסיקים מפרסמים משרות. עובדים מפרסמים פרופיל. שני הצדדים מדברים
              ישירות — בטלפון או בוואטסאפ, בלי מתווכים ובלי טפסים.
            </p>

            <div className="mt-8 flex flex-wrap gap-3">
              <Button size="lg" asChild>
                <Link href="/jobs">
                  לצפייה במשרות <ArrowLeft />
                </Link>
              </Button>
              <Button size="lg" variant="outline" asChild>
                <Link href="/workers">לצפייה בעובדים</Link>
              </Button>
            </div>
          </div>

          <div className="animate-fade-up [animation-delay:120ms]">
            <HomeSearch />
          </div>
        </div>
      </section>

      {/* Latest jobs */}
      <section className="container">
        <div className="flex items-end justify-between gap-4">
          <div>
            <p className="meta-rail">משרות אחרונות</p>
            <h2 className="mt-2 font-display text-2xl font-extrabold tracking-tight sm:text-3xl">
              מי מגייס עכשיו
            </h2>
          </div>
          <Button variant="ghost" asChild>
            <Link href="/jobs">
              כל המשרות <ArrowLeft />
            </Link>
          </Button>
        </div>

        <div className="mt-8">
          {jobs.length ? (
            <div className="grid gap-5 md:grid-cols-2 lg:grid-cols-3">
              {jobs.map((job) => (
                <JobCard key={job.id} job={job} />
              ))}
            </div>
          ) : (
            <EmptyState
              title="אין עדיין משרות"
              description="פרסמו את המשרה הראשונה בלוח — זה לוקח דקה."
              actionLabel="פרסום משרה"
              actionHref="/jobs/new"
            />
          )}
        </div>
      </section>

      {/* Latest workers */}
      <section className="container">
        <div className="flex items-end justify-between gap-4">
          <div>
            <p className="meta-rail">עובדים אחרונים</p>
            <h2 className="mt-2 font-display text-2xl font-extrabold tracking-tight sm:text-3xl">
              מי מחפש עבודה
            </h2>
          </div>
          <Button variant="ghost" asChild>
            <Link href="/workers">
              כל העובדים <ArrowLeft />
            </Link>
          </Button>
        </div>

        <div className="mt-8">
          {workers.length ? (
            <div className="grid gap-5 md:grid-cols-2 lg:grid-cols-3">
              {workers.map((worker) => (
                <WorkerCard key={worker.id} worker={worker} />
              ))}
            </div>
          ) : (
            <EmptyState
              title="אין עדיין עובדים"
              description="פרסמו פרופיל עובד ותנו למעסיקים למצוא אתכם."
              actionLabel="פרסום פרופיל"
              actionHref="/workers/new"
            />
          )}
        </div>
      </section>
    </div>
  );
}
