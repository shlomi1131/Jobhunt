import type { Metadata } from "next";
import { RegisterForm } from "@/components/auth/register-form";

export const metadata: Metadata = { title: "הרשמה" };

export default function RegisterPage() {
  return (
    <div className="container flex justify-center py-16">
      <div className="w-full max-w-md">
        <h1 className="font-display text-3xl font-extrabold tracking-tight">
          פתיחת חשבון
        </h1>
        <p className="mt-2 text-muted-foreground">
          בחרו את סוג החשבון — אפשר לפרסם משרה או לפרסם פרופיל עובד.
        </p>
        <div className="mt-8">
          <RegisterForm />
        </div>
      </div>
    </div>
  );
}
