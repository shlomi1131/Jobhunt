import { Suspense } from "react";
import type { Metadata } from "next";
import { LoginForm } from "@/components/auth/login-form";

export const metadata: Metadata = { title: "כניסה" };

export default function LoginPage() {
  return (
    <div className="container flex justify-center py-16">
      <div className="w-full max-w-md">
        <h1 className="font-display text-3xl font-extrabold tracking-tight">כניסה</h1>
        <p className="mt-2 text-muted-foreground">
          התחברו כדי לנהל את הפרסומים שלכם.
        </p>
        <div className="mt-8">
          <Suspense fallback={null}>
            <LoginForm />
          </Suspense>
        </div>
      </div>
    </div>
  );
}
