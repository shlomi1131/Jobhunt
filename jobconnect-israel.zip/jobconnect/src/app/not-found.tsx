import Link from "next/link";
import { Button } from "@/components/ui/button";

export default function NotFound() {
  return (
    <div className="container flex flex-col items-center justify-center py-32 text-center">
      <p className="meta-rail">404</p>
      <h1 className="mt-3 font-display text-3xl font-extrabold tracking-tight">
        הדף לא נמצא
      </h1>
      <p className="mt-2 max-w-sm text-muted-foreground">
        ייתכן שהפרסום נמחק או שהקישור שגוי.
      </p>
      <Button className="mt-8" asChild>
        <Link href="/">חזרה לדף הבית</Link>
      </Button>
    </div>
  );
}
