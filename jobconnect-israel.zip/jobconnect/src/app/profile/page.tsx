import type { Metadata } from "next";
import { requireProfile } from "@/lib/auth";
import { ProfileForm } from "@/components/profile-form";
import { SignOutButton } from "@/components/user-menu";

export const metadata: Metadata = { title: "הפרופיל שלי" };
export const dynamic = "force-dynamic";

export default async function ProfilePage() {
  const profile = await requireProfile("/profile");

  return (
    <div className="container max-w-2xl py-12">
      <header className="mb-8 flex items-end justify-between gap-4">
        <div>
          <p className="meta-rail">
            <span>{profile.role === "EMPLOYER" ? "מעסיק" : "מחפש/ת עבודה"}</span>
            <span className="rail-dot" />
            <span dir="ltr">{profile.email}</span>
          </p>
          <h1 className="mt-2 font-display text-3xl font-extrabold tracking-tight">
            הפרופיל שלי
          </h1>
        </div>
        <SignOutButton />
      </header>

      <ProfileForm profile={profile} />
    </div>
  );
}
