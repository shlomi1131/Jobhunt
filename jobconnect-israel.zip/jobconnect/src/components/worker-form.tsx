"use client";

import * as React from "react";
import { useRouter } from "next/navigation";
import { Controller, useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { X } from "lucide-react";
import { toast } from "sonner";
import type { WorkerPost } from "@prisma/client";
import { workerSchema, type WorkerInput } from "@/lib/validations";
import { CITIES } from "@/lib/constants";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Badge } from "@/components/ui/badge";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Field } from "@/components/field";

export function WorkerForm({
  post,
  defaultName,
}: {
  post?: WorkerPost;
  defaultName?: string;
}) {
  const router = useRouter();
  const [skillDraft, setSkillDraft] = React.useState("");

  const {
    register,
    handleSubmit,
    control,
    formState: { errors, isSubmitting },
  } = useForm<WorkerInput>({
    resolver: zodResolver(workerSchema),
    defaultValues: {
      name: post?.name ?? defaultName ?? "",
      city: post?.city ?? "",
      about: post?.about ?? "",
      skills: post?.skills ?? [],
      experience: post?.experience ?? "",
      phone: post?.phone ?? "",
      whatsapp: post?.whatsapp ?? "",
      email: post?.email ?? "",
    },
  });

  async function onSubmit(values: WorkerInput) {
    const response = await fetch(post ? `/api/workers/${post.id}` : "/api/workers", {
      method: post ? "PATCH" : "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(values),
    });

    if (!response.ok) {
      const data = await response.json().catch(() => ({}));
      toast.error(data.error ?? "השמירה נכשלה");
      return;
    }

    const saved: WorkerPost = await response.json();
    toast.success(post ? "הפרופיל עודכן" : "הפרופיל פורסם");
    router.push(`/workers/${saved.id}`);
    router.refresh();
  }

  return (
    <form onSubmit={handleSubmit(onSubmit)} className="flex flex-col gap-6">
      <div className="grid gap-6 sm:grid-cols-2">
        <Field label="שם" htmlFor="name" error={errors.name?.message}>
          <Input id="name" {...register("name")} />
        </Field>

        <Field label="עיר" htmlFor="city" error={errors.city?.message}>
          <Controller
            control={control}
            name="city"
            render={({ field }) => (
              <Select value={field.value} onValueChange={field.onChange}>
                <SelectTrigger id="city">
                  <SelectValue placeholder="בחרו עיר" />
                </SelectTrigger>
                <SelectContent>
                  {CITIES.map((city) => (
                    <SelectItem key={city} value={city}>
                      {city}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            )}
          />
        </Field>
      </div>

      <Field
        label="קצת עליי"
        htmlFor="about"
        error={errors.about?.message}
        hint="מה אתם עושים, מה אתם מחפשים, ומתי אתם זמינים."
      >
        <Textarea id="about" {...register("about")} />
      </Field>

      <Field
        label="כישורים"
        htmlFor="skills"
        error={errors.skills?.message as string | undefined}
        hint="הקלידו כישור והקישו Enter."
      >
        <Controller
          control={control}
          name="skills"
          render={({ field }) => (
            <div className="flex flex-col gap-3">
              <Input
                id="skills"
                value={skillDraft}
                onChange={(event) => setSkillDraft(event.target.value)}
                onKeyDown={(event) => {
                  if (event.key !== "Enter") return;
                  event.preventDefault();
                  const value = skillDraft.trim();
                  if (!value || field.value.includes(value)) return;
                  field.onChange([...field.value, value]);
                  setSkillDraft("");
                }}
                placeholder="למשל: מיזוג אוויר"
              />
              {field.value.length ? (
                <div className="flex flex-wrap gap-2">
                  {field.value.map((skill) => (
                    <Badge key={skill} className="gap-1 py-1 ps-1">
                      <button
                        type="button"
                        aria-label={`הסרת ${skill}`}
                        onClick={() =>
                          field.onChange(field.value.filter((s) => s !== skill))
                        }
                        className="rounded-full p-0.5 hover:bg-primary/20"
                      >
                        <X className="h-3 w-3" />
                      </button>
                      {skill}
                    </Badge>
                  ))}
                </div>
              ) : null}
            </div>
          )}
        />
      </Field>

      <Field
        label="ניסיון"
        htmlFor="experience"
        error={errors.experience?.message}
        hint="לדוגמה: 3 שנים"
      >
        <Input id="experience" {...register("experience")} />
      </Field>

      <div className="grid gap-6 sm:grid-cols-3">
        <Field label="טלפון" htmlFor="phone" error={errors.phone?.message}>
          <Input id="phone" inputMode="tel" dir="ltr" {...register("phone")} />
        </Field>

        <Field label="וואטסאפ" htmlFor="whatsapp" error={errors.whatsapp?.message}>
          <Input id="whatsapp" inputMode="tel" dir="ltr" {...register("whatsapp")} />
        </Field>

        <Field label="אימייל" htmlFor="email" error={errors.email?.message}>
          <Input id="email" type="email" dir="ltr" {...register("email")} />
        </Field>
      </div>

      <div className="flex gap-3">
        <Button type="submit" size="lg" disabled={isSubmitting}>
          {isSubmitting ? "שומר…" : post ? "שמירת שינויים" : "פרסום הפרופיל"}
        </Button>
        <Button type="button" variant="ghost" size="lg" onClick={() => router.back()}>
          ביטול
        </Button>
      </div>
    </form>
  );
}
