"use client";

import * as React from "react";
import { useSearchParams } from "next/navigation";
import { useWorkersFeed } from "@/hooks/use-feed";
import { useDebounced } from "@/hooks/use-debounced";
import { Button } from "@/components/ui/button";
import { WorkerCard } from "@/components/worker-card";
import { FeedFilters } from "@/components/feed-filters";
import { EmptyState } from "@/components/empty-state";
import { CardSkeletonGrid } from "@/components/card-skeleton";

export function WorkersFeed() {
  const searchParams = useSearchParams();
  const [query, setQuery] = React.useState(searchParams.get("q") ?? "");
  const [city, setCity] = React.useState(searchParams.get("city") ?? "");

  const debouncedQuery = useDebounced(query);

  const {
    data,
    isLoading,
    isError,
    refetch,
    fetchNextPage,
    hasNextPage,
    isFetchingNextPage,
  } = useWorkersFeed({ q: debouncedQuery, city });

  const workers = data?.pages.flatMap((page) => page.items) ?? [];
  const total = data?.pages[0]?.total ?? 0;

  return (
    <div className="flex flex-col gap-6">
      <FeedFilters
        query={query}
        city={city}
        placeholder="חיפוש לפי שם, כישור או תחום"
        onQueryChange={setQuery}
        onCityChange={setCity}
        onReset={() => {
          setQuery("");
          setCity("");
        }}
      />

      {isLoading ? <CardSkeletonGrid /> : null}

      {isError ? (
        <div className="rounded-2xl border border-destructive/30 bg-destructive/5 p-6 text-center">
          <p className="text-sm text-foreground">טעינת העובדים נכשלה.</p>
          <Button variant="outline" size="sm" className="mt-4" onClick={() => refetch()}>
            נסו שוב
          </Button>
        </div>
      ) : null}

      {!isLoading && !isError && workers.length === 0 ? (
        <EmptyState
          title="לא נמצאו עובדים"
          description="שנו את החיפוש או הסירו את הסינון כדי לראות פרופילים נוספים."
        />
      ) : null}

      {workers.length > 0 ? (
        <>
          <p className="font-mono text-[11px] uppercase tracking-[0.14em] text-muted-foreground">
            {total} עובדים
          </p>
          <div className="grid gap-5 md:grid-cols-2 lg:grid-cols-3">
            {workers.map((worker) => (
              <WorkerCard key={worker.id} worker={worker} />
            ))}
          </div>
        </>
      ) : null}

      {hasNextPage ? (
        <div className="flex justify-center pt-2">
          <Button
            variant="outline"
            onClick={() => fetchNextPage()}
            disabled={isFetchingNextPage}
          >
            {isFetchingNextPage ? "טוען…" : "טעינת עובדים נוספים"}
          </Button>
        </div>
      ) : null}
    </div>
  );
}
