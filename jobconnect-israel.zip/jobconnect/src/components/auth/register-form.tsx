"use client";

import Link from "next/link";
import { useRouter } from "next/navigation";
import { Controller, useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { toast } from "sonner";
import { registerSchema, type RegisterInput } from "@/lib/validations";
import { ROLES } from "@/lib/constants";
import { createClient } from "@/lib/supabase/client";
import { cn } from "@/lib/utils";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Field } from "@/components/field";

export function RegisterForm() {
  const router = useRouter();

  const {
    register,
    handleSubmit,
    control,
    formState: { errors, isSubmitting },
  } = useForm<RegisterInput>({
    resolver: zodResolver(registerSchema),
    defaultValues: { fullName: "", email: "", password: "", role: "SEEKER" },
  });

  async function onSubmit(values: RegisterInput) {
    const supabase = createClient();

    const { data, error } = await supabase.auth.signUp({
      email: values.email,
      password: values.password,
      options: {
        data: { full_name: values.fullName, role: values.role },
      },
    });

    if (error) {
      toast.error(
        error.message.includes("already")
          ? "כתובת האימייל כבר רשומה"
          : "ההרשמה נכשלה. נסו שוב.",
      );
      return;
    }

    if (!data.session) {
      toast.success("שלחנו לכם מייל אימות. אשרו אותו כדי להתחבר.");
      router.push("/login");
      return;
    }

    toast.success("החשבון נוצר");
    router.push("/dashboard");
    router.refresh();
  }

  return (
    <form onSubmit={handleSubmit(onSubmit)} className="flex flex-col gap-5">
      <Field label="סוג חשבון" htmlFor="role" error={errors.role?.message}>
        <Controller
          control={control}
          name="role"
          render={({ field }) => (
            <div className="grid grid-cols-2 gap-3">
              {ROLES.map((role) => (
                <button
                  key={role.value}
                  type="button"
                  onClick={() => field.onChange(role.value)}
                  aria-pressed={field.value === role.value}
                  className={cn(
                    "rounded-xl border p-4 text-start transition-colors",
                    field.value === role.value
                      ? "border-primary bg-primary/5"
                      : "border-border bg-card hover:bg-secondary",
                  )}
                >
                  <span className="block font-display text-sm font-bold">
                    {role.label}
                  </span>
                  <span className="mt-1 block text-xs text-muted-foreground">
                    {role.description}
                  </span>
                </button>
              ))}
            </div>
          )}
        />
      </Field>

      <Field label="שם מלא" htmlFor="fullName" error={errors.fullName?.message}>
        <Input id="fullName" autoComplete="name" {...register("fullName")} />
      </Field>

      <Field label="אימייל" htmlFor="email" error={errors.email?.message}>
        <Input id="email" type="email" dir="ltr" autoComplete="email" {...register("email")} />
      </Field>

      <Field
        label="סיסמה"
        htmlFor="password"
        error={errors.password?.message}
        hint="לפחות 8 תווים."
      >
        <Input
          id="password"
          type="password"
          dir="ltr"
          autoComplete="new-password"
          {...register("password")}
        />
      </Field>

      <Button type="submit" size="lg" disabled={isSubmitting}>
        {isSubmitting ? "יוצר חשבון…" : "פתיחת חשבון"}
      </Button>

      <p className="text-center text-sm text-muted-foreground">
        כבר יש לכם חשבון?{" "}
        <Link href="/login" className="font-medium text-primary hover:underline">
          כניסה
        </Link>
      </p>
    </form>
  );
}
