"use client";

import Link from "next/link";
import { useRouter, useSearchParams } from "next/navigation";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { toast } from "sonner";
import { loginSchema, type LoginInput } from "@/lib/validations";
import { createClient } from "@/lib/supabase/client";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Field } from "@/components/field";

export function LoginForm() {
  const router = useRouter();
  const searchParams = useSearchParams();
  const redirectTo = searchParams.get("redirect") ?? "/dashboard";

  const {
    register,
    handleSubmit,
    formState: { errors, isSubmitting },
  } = useForm<LoginInput>({
    resolver: zodResolver(loginSchema),
    defaultValues: { email: "", password: "" },
  });

  async function onSubmit(values: LoginInput) {
    const supabase = createClient();
    const { error } = await supabase.auth.signInWithPassword(values);

    if (error) {
      toast.error("אימייל או סיסמה שגויים");
      return;
    }

    toast.success("ברוכים השבים");
    router.push(redirectTo);
    router.refresh();
  }

  return (
    <form onSubmit={handleSubmit(onSubmit)} className="flex flex-col gap-5">
      <Field label="אימייל" htmlFor="email" error={errors.email?.message}>
        <Input id="email" type="email" dir="ltr" autoComplete="email" {...register("email")} />
      </Field>

      <Field label="סיסמה" htmlFor="password" error={errors.password?.message}>
        <Input
          id="password"
          type="password"
          dir="ltr"
          autoComplete="current-password"
          {...register("password")}
        />
      </Field>

      <Button type="submit" size="lg" disabled={isSubmitting}>
        {isSubmitting ? "מתחבר…" : "כניסה"}
      </Button>

      <p className="text-center text-sm text-muted-foreground">
        אין לכם חשבון?{" "}
        <Link href="/register" className="font-medium text-primary hover:underline">
          הרשמה
        </Link>
      </p>
    </form>
  );
}
