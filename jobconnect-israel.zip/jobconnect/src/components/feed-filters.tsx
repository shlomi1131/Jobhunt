"use client";

import { Search, X } from "lucide-react";
import { CITIES, EMPLOYMENT_TYPES } from "@/lib/constants";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";

const ALL = "__all__";

type Props = {
  query: string;
  city: string;
  employmentType?: string;
  placeholder: string;
  withEmploymentType?: boolean;
  onQueryChange: (value: string) => void;
  onCityChange: (value: string) => void;
  onEmploymentTypeChange?: (value: string) => void;
  onReset: () => void;
};

export function FeedFilters({
  query,
  city,
  employmentType,
  placeholder,
  withEmploymentType = false,
  onQueryChange,
  onCityChange,
  onEmploymentTypeChange,
  onReset,
}: Props) {
  const isFiltered = Boolean(query || city || employmentType);

  return (
    <div className="flex flex-col gap-3 rounded-2xl border border-border bg-card p-4 shadow-card sm:flex-row sm:items-center">
      <div className="relative flex-1">
        <Search className="pointer-events-none absolute end-4 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
        <Input
          value={query}
          onChange={(event) => onQueryChange(event.target.value)}
          placeholder={placeholder}
          className="pe-11"
          aria-label={placeholder}
        />
      </div>

      <Select
        value={city || ALL}
        onValueChange={(value) => onCityChange(value === ALL ? "" : value)}
      >
        <SelectTrigger className="sm:w-48" aria-label="סינון לפי עיר">
          <SelectValue placeholder="כל הערים" />
        </SelectTrigger>
        <SelectContent>
          <SelectItem value={ALL}>כל הערים</SelectItem>
          {CITIES.map((c) => (
            <SelectItem key={c} value={c}>
              {c}
            </SelectItem>
          ))}
        </SelectContent>
      </Select>

      {withEmploymentType && onEmploymentTypeChange ? (
        <Select
          value={employmentType || ALL}
          onValueChange={(value) =>
            onEmploymentTypeChange(value === ALL ? "" : value)
          }
        >
          <SelectTrigger className="sm:w-48" aria-label="סינון לפי היקף משרה">
            <SelectValue placeholder="כל סוגי המשרה" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value={ALL}>כל סוגי המשרה</SelectItem>
            {EMPLOYMENT_TYPES.map((type) => (
              <SelectItem key={type.value} value={type.value}>
                {type.label}
              </SelectItem>
            ))}
          </SelectContent>
        </Select>
      ) : null}

      {isFiltered ? (
        <Button variant="ghost" size="sm" onClick={onReset}>
          <X /> ניקוי
        </Button>
      ) : null}
    </div>
  );
}
