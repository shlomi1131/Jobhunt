"use client";

import * as React from "react";
import { useRouter } from "next/navigation";
import { Search } from "lucide-react";
import { CITIES } from "@/lib/constants";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";

const ALL = "__all__";

export function HomeSearch() {
  const router = useRouter();
  const [query, setQuery] = React.useState("");
  const [city, setCity] = React.useState("");
  const [target, setTarget] = React.useState<"jobs" | "workers">("jobs");

  function search() {
    const params = new URLSearchParams();
    if (query.trim()) params.set("q", query.trim());
    if (city) params.set("city", city);
    router.push(`/${target}?${params.toString()}`);
  }

  return (
    <div className="rounded-2xl border border-border bg-card p-4 shadow-lift">
      <div className="mb-4 inline-flex rounded-full bg-secondary p-1">
        {(["jobs", "workers"] as const).map((value) => (
          <button
            key={value}
            type="button"
            onClick={() => setTarget(value)}
            className={`rounded-full px-4 py-1.5 text-sm font-medium transition-colors ${
              target === value
                ? "bg-card text-foreground shadow-sm"
                : "text-muted-foreground hover:text-foreground"
            }`}
          >
            {value === "jobs" ? "מחפש/ת עבודה" : "מחפש/ת עובדים"}
          </button>
        ))}
      </div>

      <div className="flex flex-col gap-3 sm:flex-row">
        <Input
          value={query}
          onChange={(event) => setQuery(event.target.value)}
          onKeyDown={(event) => event.key === "Enter" && search()}
          placeholder={
            target === "jobs"
              ? "תפקיד, חברה או מילת מפתח"
              : "שם, כישור או תחום"
          }
          className="flex-1"
          aria-label="חיפוש"
        />

        <Select
          value={city || ALL}
          onValueChange={(value) => setCity(value === ALL ? "" : value)}
        >
          <SelectTrigger className="sm:w-44" aria-label="עיר">
            <SelectValue placeholder="כל הערים" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value={ALL}>כל הערים</SelectItem>
            {CITIES.map((c) => (
              <SelectItem key={c} value={c}>
                {c}
              </SelectItem>
            ))}
          </SelectContent>
        </Select>

        <Button size="lg" onClick={search}>
          <Search /> חיפוש
        </Button>
      </div>
    </div>
  );
}
