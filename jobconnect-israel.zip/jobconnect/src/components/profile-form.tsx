"use client";

import * as React from "react";
import { useRouter } from "next/navigation";
import { Controller, useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { Upload } from "lucide-react";
import { toast } from "sonner";
import type { Profile } from "@prisma/client";
import { profileSchema, type ProfileInput } from "@/lib/validations";
import { CITIES } from "@/lib/constants";
import { createClient } from "@/lib/supabase/client";
import { initials } from "@/lib/utils";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Field } from "@/components/field";

const ALL = "__none__";

export function ProfileForm({ profile }: { profile: Profile }) {
  const router = useRouter();
  const fileInput = React.useRef<HTMLInputElement>(null);
  const [uploading, setUploading] = React.useState(false);

  const {
    register,
    handleSubmit,
    control,
    watch,
    setValue,
    formState: { errors, isSubmitting },
  } = useForm<ProfileInput>({
    resolver: zodResolver(profileSchema),
    defaultValues: {
      fullName: profile.fullName,
      city: profile.city ?? "",
      phone: profile.phone ?? "",
      avatarUrl: profile.avatarUrl ?? "",
    },
  });

  const avatarUrl = watch("avatarUrl");

  async function uploadAvatar(file: File) {
    if (file.size > 2 * 1024 * 1024) {
      toast.error("הקובץ גדול מ-2MB");
      return;
    }

    setUploading(true);
    const supabase = createClient();
    const extension = file.name.split(".").pop() ?? "jpg";
    const path = `${profile.id}/${Date.now()}.${extension}`;

    const { error } = await supabase.storage
      .from("avatars")
      .upload(path, file, { upsert: true, contentType: file.type });

    if (error) {
      setUploading(false);
      toast.error("העלאת התמונה נכשלה");
      return;
    }

    const {
      data: { publicUrl },
    } = supabase.storage.from("avatars").getPublicUrl(path);

    setValue("avatarUrl", publicUrl, { shouldDirty: true });
    setUploading(false);
    toast.success("התמונה הועלתה. שמרו כדי לעדכן את הפרופיל.");
  }

  async function onSubmit(values: ProfileInput) {
    const response = await fetch("/api/profile", {
      method: "PATCH",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(values),
    });

    if (!response.ok) {
      const data = await response.json().catch(() => ({}));
      toast.error(data.error ?? "השמירה נכשלה");
      return;
    }

    toast.success("הפרופיל עודכן");
    router.refresh();
  }

  return (
    <form onSubmit={handleSubmit(onSubmit)} className="flex flex-col gap-6">
      <div className="flex items-center gap-4">
        <Avatar className="h-20 w-20">
          {avatarUrl ? <AvatarImage src={avatarUrl} alt={profile.fullName} /> : null}
          <AvatarFallback className="text-lg">
            {initials(profile.fullName)}
          </AvatarFallback>
        </Avatar>

        <div>
          <Button
            type="button"
            variant="outline"
            size="sm"
            disabled={uploading}
            onClick={() => fileInput.current?.click()}
          >
            <Upload /> {uploading ? "מעלה…" : "החלפת תמונה"}
          </Button>
          <p className="mt-2 text-xs text-muted-foreground">
            JPG או PNG, עד 2MB.
          </p>
          <input
            ref={fileInput}
            type="file"
            accept="image/*"
            className="hidden"
            onChange={(event) => {
              const file = event.target.files?.[0];
              if (file) void uploadAvatar(file);
              event.target.value = "";
            }}
          />
        </div>
      </div>

      <Field label="שם מלא" htmlFor="fullName" error={errors.fullName?.message}>
        <Input id="fullName" {...register("fullName")} />
      </Field>

      <div className="grid gap-6 sm:grid-cols-2">
        <Field label="עיר" htmlFor="city" error={errors.city?.message}>
          <Controller
            control={control}
            name="city"
            render={({ field }) => (
              <Select
                value={field.value || ALL}
                onValueChange={(value) => field.onChange(value === ALL ? "" : value)}
              >
                <SelectTrigger id="city">
                  <SelectValue placeholder="בחרו עיר" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value={ALL}>ללא</SelectItem>
                  {CITIES.map((city) => (
                    <SelectItem key={city} value={city}>
                      {city}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            )}
          />
        </Field>

        <Field label="טלפון" htmlFor="phone" error={errors.phone?.message}>
          <Input id="phone" inputMode="tel" dir="ltr" {...register("phone")} />
        </Field>
      </div>

      <div>
        <Button type="submit" size="lg" disabled={isSubmitting || uploading}>
          {isSubmitting ? "שומר…" : "שמירת שינויים"}
        </Button>
      </div>
    </form>
  );
}
