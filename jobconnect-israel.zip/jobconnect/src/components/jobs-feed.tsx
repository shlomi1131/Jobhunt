"use client";

import * as React from "react";
import { useSearchParams } from "next/navigation";
import { useJobsFeed } from "@/hooks/use-feed";
import { useDebounced } from "@/hooks/use-debounced";
import { Button } from "@/components/ui/button";
import { JobCard } from "@/components/job-card";
import { FeedFilters } from "@/components/feed-filters";
import { EmptyState } from "@/components/empty-state";
import { CardSkeletonGrid } from "@/components/card-skeleton";

export function JobsFeed() {
  const searchParams = useSearchParams();
  const [query, setQuery] = React.useState(searchParams.get("q") ?? "");
  const [city, setCity] = React.useState(searchParams.get("city") ?? "");
  const [employmentType, setEmploymentType] = React.useState("");

  const debouncedQuery = useDebounced(query);

  const {
    data,
    isLoading,
    isError,
    refetch,
    fetchNextPage,
    hasNextPage,
    isFetchingNextPage,
  } = useJobsFeed({ q: debouncedQuery, city, employmentType });

  const jobs = data?.pages.flatMap((page) => page.items) ?? [];
  const total = data?.pages[0]?.total ?? 0;

  return (
    <div className="flex flex-col gap-6">
      <FeedFilters
        query={query}
        city={city}
        employmentType={employmentType}
        placeholder="חיפוש לפי תפקיד, חברה או מילת מפתח"
        withEmploymentType
        onQueryChange={setQuery}
        onCityChange={setCity}
        onEmploymentTypeChange={setEmploymentType}
        onReset={() => {
          setQuery("");
          setCity("");
          setEmploymentType("");
        }}
      />

      {isLoading ? <CardSkeletonGrid /> : null}

      {isError ? (
        <div className="rounded-2xl border border-destructive/30 bg-destructive/5 p-6 text-center">
          <p className="text-sm text-foreground">טעינת המשרות נכשלה.</p>
          <Button variant="outline" size="sm" className="mt-4" onClick={() => refetch()}>
            נסו שוב
          </Button>
        </div>
      ) : null}

      {!isLoading && !isError && jobs.length === 0 ? (
        <EmptyState
          title="לא נמצאו משרות"
          description="שנו את החיפוש או הסירו את הסינון כדי לראות משרות נוספות."
        />
      ) : null}

      {jobs.length > 0 ? (
        <>
          <p className="font-mono text-[11px] uppercase tracking-[0.14em] text-muted-foreground">
            {total} משרות
          </p>
          <div className="grid gap-5 md:grid-cols-2 lg:grid-cols-3">
            {jobs.map((job) => (
              <JobCard key={job.id} job={job} />
            ))}
          </div>
        </>
      ) : null}

      {hasNextPage ? (
        <div className="flex justify-center pt-2">
          <Button
            variant="outline"
            onClick={() => fetchNextPage()}
            disabled={isFetchingNextPage}
          >
            {isFetchingNextPage ? "טוען…" : "טעינת משרות נוספות"}
          </Button>
        </div>
      ) : null}
    </div>
  );
}
