import Link from "next/link";
import { Building2, MapPin } from "lucide-react";
import type { JobWithAuthor } from "@/types";
import { employmentLabel } from "@/lib/constants";
import { timeAgo } from "@/lib/utils";
import { Badge } from "@/components/ui/badge";
import { ContactButtons } from "@/components/contact-buttons";

export function JobCard({ job }: { job: JobWithAuthor }) {
  return (
    <article className="group flex flex-col rounded-2xl border border-border bg-card shadow-card transition-all hover:-translate-y-0.5 hover:shadow-lift">
      {/* meta rail — the card's index-strip */}
      <div className="meta-rail border-b border-dashed border-border px-5 py-2.5">
        <span>{employmentLabel(job.employmentType)}</span>
        <span className="rail-dot" />
        <span className="truncate">{job.salary || "שכר לא צוין"}</span>
        <span className="ms-auto shrink-0 normal-case tracking-normal">
          {timeAgo(job.createdAt)}
        </span>
      </div>

      <div className="flex flex-1 flex-col gap-3 p-5">
        <div>
          <h3 className="font-display text-lg font-bold leading-snug tracking-tight">
            <Link href={`/jobs/${job.id}`} className="hover:text-primary">
              {job.title}
            </Link>
          </h3>
          <div className="mt-1.5 flex flex-wrap items-center gap-x-4 gap-y-1 text-sm text-muted-foreground">
            <span className="inline-flex items-center gap-1.5">
              <Building2 className="h-3.5 w-3.5" /> {job.company}
            </span>
            <span className="inline-flex items-center gap-1.5">
              <MapPin className="h-3.5 w-3.5" /> {job.city}
            </span>
          </div>
        </div>

        <p className="line-clamp-2 text-sm leading-relaxed text-muted-foreground">
          {job.description}
        </p>

        <div className="mt-auto flex flex-wrap items-center justify-between gap-3 pt-2">
          <Badge variant="outline">{job.city}</Badge>
          <ContactButtons
            phone={job.phone}
            whatsapp={job.whatsapp}
            email={job.email}
            shareTitle={job.title}
            shareUrl={`/jobs/${job.id}`}
          />
        </div>
      </div>
    </article>
  );
}
