"use client";

import * as React from "react";
import { useRouter } from "next/navigation";
import { Trash2 } from "lucide-react";
import { toast } from "sonner";
import { Button } from "@/components/ui/button";
import {
  Dialog,
  DialogClose,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";

type Props = {
  resource: "jobs" | "workers";
  id: string;
  title: string;
  redirectTo?: string;
};

export function DeleteButton({ resource, id, title, redirectTo }: Props) {
  const router = useRouter();
  const [open, setOpen] = React.useState(false);
  const [pending, setPending] = React.useState(false);

  async function remove() {
    setPending(true);
    const response = await fetch(`/api/${resource}/${id}`, { method: "DELETE" });
    setPending(false);

    if (!response.ok) {
      const data = await response.json().catch(() => ({}));
      toast.error(data.error ?? "המחיקה נכשלה");
      return;
    }

    setOpen(false);
    toast.success("הפרסום נמחק");
    router.push(redirectTo ?? "/dashboard");
    router.refresh();
  }

  return (
    <Dialog open={open} onOpenChange={setOpen}>
      <DialogTrigger asChild>
        <Button variant="ghost" size="sm" className="text-destructive">
          <Trash2 /> מחיקה
        </Button>
      </DialogTrigger>
      <DialogContent>
        <DialogHeader>
          <DialogTitle>למחוק את &quot;{title}&quot;?</DialogTitle>
          <DialogDescription>
            הפרסום יוסר מהלוח לצמיתות. לא ניתן לשחזר אותו.
          </DialogDescription>
        </DialogHeader>
        <DialogFooter>
          <Button variant="destructive" onClick={remove} disabled={pending}>
            {pending ? "מוחק…" : "מחיקה"}
          </Button>
          <DialogClose asChild>
            <Button variant="ghost">ביטול</Button>
          </DialogClose>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}
