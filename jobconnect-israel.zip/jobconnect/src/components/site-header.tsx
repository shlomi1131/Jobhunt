import Link from "next/link";
import { Plus } from "lucide-react";
import { getProfile } from "@/lib/auth";
import { Button } from "@/components/ui/button";
import { ThemeToggle } from "@/components/theme-toggle";
import { UserMenu } from "@/components/user-menu";

export async function SiteHeader() {
  const profile = await getProfile();
  const publishHref = profile?.role === "EMPLOYER" ? "/jobs/new" : "/workers/new";
  const publishLabel =
    profile?.role === "EMPLOYER" ? "פרסום משרה" : "פרסום פרופיל";

  return (
    <header className="sticky top-0 z-40 border-b border-border bg-background/80 backdrop-blur-md">
      <div className="container flex h-16 items-center justify-between gap-4">
        <div className="flex items-center gap-7">
          <Link href="/" className="flex items-center gap-2">
            <span className="grid h-8 w-8 place-items-center rounded-lg bg-primary font-display text-sm font-extrabold text-primary-foreground">
              JC
            </span>
            <span className="font-display text-lg font-extrabold tracking-tight">
              JobConnect
            </span>
          </Link>

          <nav className="hidden items-center gap-1 md:flex">
            <Button variant="ghost" size="sm" asChild>
              <Link href="/jobs">משרות</Link>
            </Button>
            <Button variant="ghost" size="sm" asChild>
              <Link href="/workers">עובדים</Link>
            </Button>
          </nav>
        </div>

        <div className="flex items-center gap-2">
          <ThemeToggle />
          {profile ? (
            <>
              <Button size="sm" variant="accent" asChild className="hidden sm:inline-flex">
                <Link href={publishHref}>
                  <Plus /> {publishLabel}
                </Link>
              </Button>
              <UserMenu profile={profile} />
            </>
          ) : (
            <>
              <Button variant="ghost" size="sm" asChild>
                <Link href="/login">כניסה</Link>
              </Button>
              <Button size="sm" asChild>
                <Link href="/register">הרשמה</Link>
              </Button>
            </>
          )}
        </div>
      </div>
    </header>
  );
}
