import Link from "next/link";
import { Briefcase, MapPin } from "lucide-react";
import type { WorkerWithAuthor } from "@/types";
import { initials, timeAgo } from "@/lib/utils";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Badge } from "@/components/ui/badge";
import { ContactButtons } from "@/components/contact-buttons";

export function WorkerCard({ worker }: { worker: WorkerWithAuthor }) {
  return (
    <article className="group flex flex-col rounded-2xl border border-border bg-card shadow-card transition-all hover:-translate-y-0.5 hover:shadow-lift">
      <div className="meta-rail border-b border-dashed border-border px-5 py-2.5">
        <span>מחפש/ת עבודה</span>
        <span className="rail-dot" />
        <span className="truncate">{worker.experience || "ללא ניסיון"}</span>
        <span className="ms-auto shrink-0 normal-case tracking-normal">
          {timeAgo(worker.createdAt)}
        </span>
      </div>

      <div className="flex flex-1 flex-col gap-3 p-5">
        <div className="flex items-start gap-3">
          <Avatar>
            {worker.author.avatarUrl ? (
              <AvatarImage src={worker.author.avatarUrl} alt={worker.name} />
            ) : null}
            <AvatarFallback>{initials(worker.name)}</AvatarFallback>
          </Avatar>
          <div className="min-w-0">
            <h3 className="font-display text-lg font-bold leading-snug tracking-tight">
              <Link href={`/workers/${worker.id}`} className="hover:text-primary">
                {worker.name}
              </Link>
            </h3>
            <div className="mt-1 flex flex-wrap items-center gap-x-4 gap-y-1 text-sm text-muted-foreground">
              <span className="inline-flex items-center gap-1.5">
                <MapPin className="h-3.5 w-3.5" /> {worker.city}
              </span>
              {worker.experience ? (
                <span className="inline-flex items-center gap-1.5">
                  <Briefcase className="h-3.5 w-3.5" /> {worker.experience}
                </span>
              ) : null}
            </div>
          </div>
        </div>

        <p className="line-clamp-2 text-sm leading-relaxed text-muted-foreground">
          {worker.about}
        </p>

        {worker.skills.length ? (
          <div className="flex flex-wrap gap-1.5">
            {worker.skills.slice(0, 4).map((skill) => (
              <Badge key={skill}>{skill}</Badge>
            ))}
            {worker.skills.length > 4 ? (
              <Badge variant="outline">+{worker.skills.length - 4}</Badge>
            ) : null}
          </div>
        ) : null}

        <div className="mt-auto pt-2">
          <ContactButtons
            phone={worker.phone}
            whatsapp={worker.whatsapp}
            email={worker.email}
            shareTitle={worker.name}
            shareUrl={`/workers/${worker.id}`}
          />
        </div>
      </div>
    </article>
  );
}
