"use client";

import { useRouter } from "next/navigation";
import { Controller, useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { toast } from "sonner";
import type { Job } from "@prisma/client";
import { jobSchema, type JobInput } from "@/lib/validations";
import { CITIES, EMPLOYMENT_TYPES } from "@/lib/constants";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Field } from "@/components/field";

export function JobForm({ job }: { job?: Job }) {
  const router = useRouter();

  const {
    register,
    handleSubmit,
    control,
    formState: { errors, isSubmitting },
  } = useForm<JobInput>({
    resolver: zodResolver(jobSchema),
    defaultValues: {
      title: job?.title ?? "",
      company: job?.company ?? "",
      city: job?.city ?? "",
      description: job?.description ?? "",
      salary: job?.salary ?? "",
      employmentType: job?.employmentType ?? "FULL_TIME",
      phone: job?.phone ?? "",
      whatsapp: job?.whatsapp ?? "",
      email: job?.email ?? "",
    },
  });

  async function onSubmit(values: JobInput) {
    const response = await fetch(job ? `/api/jobs/${job.id}` : "/api/jobs", {
      method: job ? "PATCH" : "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(values),
    });

    if (!response.ok) {
      const data = await response.json().catch(() => ({}));
      toast.error(data.error ?? "השמירה נכשלה");
      return;
    }

    const saved: Job = await response.json();
    toast.success(job ? "המשרה עודכנה" : "המשרה פורסמה");
    router.push(`/jobs/${saved.id}`);
    router.refresh();
  }

  return (
    <form onSubmit={handleSubmit(onSubmit)} className="flex flex-col gap-6">
      <Field label="כותרת המשרה" htmlFor="title" error={errors.title?.message}>
        <Input id="title" placeholder="למשל: מלצר/ית למשמרות ערב" {...register("title")} />
      </Field>

      <div className="grid gap-6 sm:grid-cols-2">
        <Field label="שם החברה" htmlFor="company" error={errors.company?.message}>
          <Input id="company" {...register("company")} />
        </Field>

        <Field label="עיר" htmlFor="city" error={errors.city?.message}>
          <Controller
            control={control}
            name="city"
            render={({ field }) => (
              <Select value={field.value} onValueChange={field.onChange}>
                <SelectTrigger id="city">
                  <SelectValue placeholder="בחרו עיר" />
                </SelectTrigger>
                <SelectContent>
                  {CITIES.map((city) => (
                    <SelectItem key={city} value={city}>
                      {city}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            )}
          />
        </Field>
      </div>

      <Field
        label="תיאור המשרה"
        htmlFor="description"
        error={errors.description?.message}
        hint="מה התפקיד כולל, אילו שעות, ומה נדרש מהמועמד/ת."
      >
        <Textarea id="description" {...register("description")} />
      </Field>

      <div className="grid gap-6 sm:grid-cols-2">
        <Field
          label="שכר"
          htmlFor="salary"
          error={errors.salary?.message}
          hint="לדוגמה: 55 ₪ לשעה, או 15,000–18,000 ₪"
        >
          <Input id="salary" {...register("salary")} />
        </Field>

        <Field
          label="היקף משרה"
          htmlFor="employmentType"
          error={errors.employmentType?.message}
        >
          <Controller
            control={control}
            name="employmentType"
            render={({ field }) => (
              <Select value={field.value} onValueChange={field.onChange}>
                <SelectTrigger id="employmentType">
                  <SelectValue placeholder="בחרו היקף" />
                </SelectTrigger>
                <SelectContent>
                  {EMPLOYMENT_TYPES.map((type) => (
                    <SelectItem key={type.value} value={type.value}>
                      {type.label}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            )}
          />
        </Field>
      </div>

      <div className="grid gap-6 sm:grid-cols-3">
        <Field label="טלפון" htmlFor="phone" error={errors.phone?.message}>
          <Input id="phone" inputMode="tel" dir="ltr" {...register("phone")} />
        </Field>

        <Field label="וואטסאפ" htmlFor="whatsapp" error={errors.whatsapp?.message}>
          <Input id="whatsapp" inputMode="tel" dir="ltr" {...register("whatsapp")} />
        </Field>

        <Field label="אימייל" htmlFor="email" error={errors.email?.message}>
          <Input id="email" type="email" dir="ltr" {...register("email")} />
        </Field>
      </div>

      <div className="flex gap-3">
        <Button type="submit" size="lg" disabled={isSubmitting}>
          {isSubmitting ? "שומר…" : job ? "שמירת שינויים" : "פרסום המשרה"}
        </Button>
        <Button type="button" variant="ghost" size="lg" onClick={() => router.back()}>
          ביטול
        </Button>
      </div>
    </form>
  );
}
