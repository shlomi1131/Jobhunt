import Link from "next/link";

export function SiteFooter() {
  return (
    <footer className="mt-24 border-t border-border bg-card">
      <div className="container flex flex-col gap-6 py-10 md:flex-row md:items-center md:justify-between">
        <div>
          <p className="font-display text-base font-extrabold">JobConnect</p>
          <p className="mt-1 text-sm text-muted-foreground">
            מחברים מעסיקים ועובדים בישראל. בלי מתווכים.
          </p>
        </div>
        <nav className="flex flex-wrap gap-x-6 gap-y-2 text-sm text-muted-foreground">
          <Link href="/jobs" className="hover:text-foreground">
            משרות
          </Link>
          <Link href="/workers" className="hover:text-foreground">
            עובדים
          </Link>
          <Link href="/register" className="hover:text-foreground">
            פתיחת חשבון
          </Link>
        </nav>
        <p className="font-mono text-[11px] uppercase tracking-[0.14em] text-muted-foreground">
          © {new Date().getFullYear()} JobConnect IL
        </p>
      </div>
    </footer>
  );
}
