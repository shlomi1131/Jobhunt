"use client";

import { Mail, MessageCircle, Phone, Share2 } from "lucide-react";
import { toast } from "sonner";
import { Button } from "@/components/ui/button";
import { waLink } from "@/lib/utils";

type Props = {
  phone?: string | null;
  whatsapp?: string | null;
  email?: string | null;
  shareTitle: string;
  shareUrl: string;
  size?: "sm" | "default";
};

export function ContactButtons({
  phone,
  whatsapp,
  email,
  shareTitle,
  shareUrl,
  size = "sm",
}: Props) {
  async function share() {
    const url = new URL(shareUrl, window.location.origin).toString();

    if (navigator.share) {
      try {
        await navigator.share({ title: shareTitle, url });
        return;
      } catch {
        // The user dismissed the share sheet — fall back to copying.
      }
    }

    await navigator.clipboard.writeText(url);
    toast.success("הקישור הועתק");
  }

  return (
    <div className="flex flex-wrap items-center gap-2">
      {phone ? (
        <Button variant="outline" size={size} asChild>
          <a href={`tel:${phone}`}>
            <Phone /> חיוג
          </a>
        </Button>
      ) : null}

      {whatsapp ? (
        <Button variant="accent" size={size} asChild>
          <a
            href={waLink(whatsapp, `שלום, ראיתי את "${shareTitle}" ב-JobConnect`)}
            target="_blank"
            rel="noopener noreferrer"
          >
            <MessageCircle /> וואטסאפ
          </a>
        </Button>
      ) : null}

      {email ? (
        <Button variant="outline" size={size} asChild>
          <a href={`mailto:${email}?subject=${encodeURIComponent(shareTitle)}`}>
            <Mail /> אימייל
          </a>
        </Button>
      ) : null}

      <Button variant="ghost" size={size} onClick={share}>
        <Share2 /> שיתוף
      </Button>
    </div>
  );
}
