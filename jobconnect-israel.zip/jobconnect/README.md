# JobConnect IL — לוח משרות ועובדים (Hebrew RTL)

Job marketplace MVP connecting **employers** (post jobs) and **job seekers** (post "looking for work" profiles). Hebrew-first, RTL, mobile-first, light + dark.

**Stack:** Next.js 15 (App Router) · TypeScript · Tailwind · shadcn/ui · Prisma · Supabase (auth + storage) · React Hook Form · Zod · React Query.

---

## Setup (5 minutes)

### 1. Install

```bash
npm install
```

### 2. Create a Supabase project

Go to [supabase.com](https://supabase.com) → New project.

Then collect:

| Value | Where |
| --- | --- |
| `NEXT_PUBLIC_SUPABASE_URL` | Project Settings → API → Project URL |
| `NEXT_PUBLIC_SUPABASE_ANON_KEY` | Project Settings → API → `anon public` key |
| `DATABASE_URL` | Project Settings → Database → Connection string → **Transaction** (port 6543), add `?pgbouncer=true` |
| `DIRECT_URL` | Same page → **Session** (port 5432) |

### 3. Environment

```bash
cp .env.example .env
```

Fill in the four values above plus `NEXT_PUBLIC_SITE_URL=http://localhost:3000`.

### 4. Database

```bash
npx prisma migrate deploy   # or: npm run db:push
npm run db:seed             # optional demo data
```

### 5. Avatar storage

In Supabase → Storage → **New bucket** named `avatars`, marked **Public**.

Then allow authenticated uploads (SQL editor):

```sql
create policy "avatar uploads" on storage.objects
  for insert to authenticated
  with check (bucket_id = 'avatars');

create policy "avatar updates" on storage.objects
  for update to authenticated
  using (bucket_id = 'avatars');
```

### 6. Auth

Supabase → Authentication → Providers → Email. For instant local testing, turn **Confirm email** off. Leave it on in production.

### 7. Run

```bash
npm run dev
```

Open http://localhost:3000

---

## How it works

**Roles.** A user picks `EMPLOYER` or `SEEKER` at registration; the role is stored in Supabase user metadata and mirrored into the `profiles` table on first authenticated request (`src/lib/auth.ts`). Employers can only post jobs; seekers can only post worker profiles — enforced on both the page and the API route.

**Data access.** Prisma talks to Postgres directly with the app's own credentials, and every write goes through an API route that checks ownership (`authorId === profile.id`). Supabase RLS is therefore not the enforcement layer here — keep `DATABASE_URL` server-side only.

**Feeds.** `/api/jobs` and `/api/workers` return paginated, filtered results (search, city, employment type). The client feeds use React Query's `useInfiniteQuery` with a debounced search box and a "load more" button.

**Contact.** Every card and detail page exposes call / WhatsApp / email / share. Israeli numbers are normalized to `wa.me/972…` in `src/lib/utils.ts`.

## Routes

| Route | What |
| --- | --- |
| `/` | Hero, search, latest jobs, latest workers |
| `/jobs` | Jobs feed — search, city filter, employment-type filter |
| `/jobs/[id]` | Job detail + contact + owner controls |
| `/jobs/new`, `/jobs/[id]/edit` | Employer only |
| `/workers` | Workers feed — search, city filter |
| `/workers/[id]` | Worker detail + contact + owner controls |
| `/workers/new`, `/workers/[id]/edit` | Seeker only |
| `/dashboard` | Own posts, edit + delete |
| `/profile` | Editable profile + avatar upload |
| `/login`, `/register` | Supabase email auth |

Protected routes are guarded in `src/middleware.ts`.

## Scripts

```bash
npm run dev        # dev server
npm run build      # prisma generate + next build
npm run typecheck  # tsc --noEmit
npm run db:push    # push schema without migrations
npm run db:migrate # create a migration
npm run db:seed    # demo jobs + worker profiles (Hebrew)
```

## Deploy (Vercel)

1. Push to GitHub, import in Vercel.
2. Add all five env vars from `.env`.
3. Set `NEXT_PUBLIC_SITE_URL` to the production domain.
4. Deploy — `npm run build` runs `prisma generate` first.

## Design notes

Palette is a deep pine primary with a vermilion accent on soft green-grey neutrals. Type: **Rubik** (display) + **Assistant** (body, Hebrew-first) + **IBM Plex Mono** (data). Every listing card opens with a mono "meta rail" — the index strip carrying type · salary · time — which is the system's signature element and the reason a card is scannable in one glance.

## Next iterations (deliberately not in the MVP)

Chat, notifications, saved jobs, applications tracking, Stripe, admin panel, analytics.
